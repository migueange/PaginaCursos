/**
*@author Miguel Torres Eric Giovanni
*@version 1.0
*/
public abstract class Piezas{
  protected boolean color;
  protected String pieza;
  protected int xi,yi;
  /**
  *Constructor con parametros
  *@param pza Es la pieza que será
  *@param col Es el color de la pieza, si es true será blanca, si es false será negra
  *@param xini Es la posicion x en el arreglo
  *@param yini Es la posicion y en el arreglo
  */
  public Piezas(String pza, boolean col, int xini, int yini){
    if(pza.equals("peon") || pza.equals("rey") || pza.equals("dama") || pza.equals("torre") || pza.toLowerCase().equals("caballo"))
      pieza = pza.toUpperCase();
    else{
      pieza = "VACIA";
    }
    if(col == true){
      color = col;
      pieza = pieza.toUpperCase();
    }else{
      pieza = pieza.toLowerCase();
    }
    if(xini > 5 || xini < 0)
      xi = 0;
    else
      xi = xini;
    if(yini > 5 || yini < 0)
      yi = 0;
    else
      yi = yini;
  }
  /**
  *Metodo para saber la posicion en x
  *@return int Es la posicion en x
  */
  public int obtenerXi(){
    return xi;
  }
  /**
  *Metodo para saber la posicion en y
  *@return int Es la posicion en y
  */
  public int obtenerYi(){
    return yi;
  }
  /**
  *Metodo para saber el color de la pieza
  *@return boolean Es el color de la pieza, true es blanca y false es negra
  */
  public boolean obtenerColor(){
    return color;
  }
  /**
  *Metodo que te devuelve la pieza que es
  *@return String Es la pieza que es
  */
  public String obtenerPieza(){
    return pieza;
  }
  /**
  *Metodo que te permite asignar la posicion en x
  *@param xini Es la posicion en x que asignaras
  */
  public void asignaXi(int xini){
    if(xini > 5 || xini < 0)
      xi = 0;
    else
      xi = xini;
  }
  /**
  *Metodo que te permite asignar la posicion en y
  *@param yini Es la posicion en y que asignaras
  */
  public void asignaYi(int yini){
    if(yini > 5 || yini < 0)
      yi = 0;
    else
      yi = yini;
  }
  /**
  *Metodo que te permite asignar el color de la pieza
  *@param col Es el color de la pieza que asignaras, true es blanca y false es negra
  */
  public void asignaColor(boolean col){
    color = col;
  }
  /**
  *Metodo que te permite cambiar el tipo de pieza
  *@param pza Es la pieza que asignaras
  */
  public void asignaPieza(String pza){
    pieza = pza.toLowerCase();
  }
  /**
  *Convierte en Caracter la pieza
  *@return String Es el caracter que representa la pieza
  */
  public String toString(){
    if(obtenerPieza().equals("VACIA") || obtenerPieza().equals("vacia"))
      return "*";
    else
      return pieza.substring(0,1);
  }
  /**
  *Metodo abstracto que te permite mover tu pieza
  *@param t Es el tablero donde se movera la pieza
  *@param xi Posicion inicial en x
  *@param yi Posicion inicial en y
  *@param xf Posicion final en x
  *@param yf Posicion final en y
  *@param turno Turno que esta presente en el juego
  *@return boolean Es el nuevo turno si es que cambio, depende de si la pieza se mueve o no
  *@throws MovimientoInvalidoExcepcion Se lanza si hay movimientos invalidos
  */
  public abstract boolean mover(Tablero t, int xi, int yi, int xf, int yf, boolean turno) throws MovimientoInvalidoExcepcion;
  /**
  *Metodo abstracto que te permite comer con tu pieza
  *@param t Es el tablero donde se movera la pieza
  *@param xi Posicion inicial en x
  *@param yi Posicion inicial en y
  *@param xf Posicion final en x
  *@param yf Posicion final en y
  *@param turno Turno que esta presente en el juego
  *@return boolean Es el nuevo turno si es que cambio, depende de si la pieza se mueve o no
  *@throws MovimientoInvalidoExcepcion Se lanza si no es posible hacer el movimiento
  */
  public abstract boolean comer(Tablero t, int xi, int yi, int xf, int yf, boolean turno) throws MovimientoInvalidoExcepcion;
  /**
  *Metodo abstracto que te permite saber si es un movimiento valido
  *@param t Es el tablero donde se movera la pieza
  *@param xi Posicion inicial en x
  *@param yi Posicion inicial en y
  *@param xf Posicion final en x
  *@param yf Posicion final en y
  *@param turno Turno que esta presente en el juego
  *@return boolean Te dice si es un movimiento valido
  */
  public abstract boolean movimientoValido(Tablero t, int xi, int yi, int xf, int yf, boolean turno);
}
