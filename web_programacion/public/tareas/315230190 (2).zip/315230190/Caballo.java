/**
*@author Miguel Torres Eric Giovanni
*@version 1.0
*/
public class Caballo extends Piezas{
  /**
  *Constructor con parametros
  *@param col Es el color de la pieza, si es true será blanca, si es false será negra
  *@param xini Es la posicion inicial en x
  *@param yini Es la posicion inicial en y
  */
  public Caballo(boolean col, int xini, int yini){
    super("caballo", col, xini, yini);
  }
  /**
  *Metodo que te permite mover tu caballo
  *@param t Es el tablero donde se movera la pieza
  *@param xi Posicion inicial en x
  *@param yi Posicion inicial en y
  *@param xf Posicion final en x
  *@param yf Posicion final en y
  *@param turno Turno que esta presente en el juego
  *@return boolean Es el nuevo turno si es que cambio, depende de si la pieza se mueve o no
  *@throws MovimientoInvalidoExcepcion Se lanza si no es posible hacer el movimiento
  */
  public boolean mover(Tablero t, int xi, int yi, int xf, int yf, boolean turno) throws MovimientoInvalidoExcepcion{
    if(t.obtenerPieza(xi,yi).obtenerColor() == turno){
      if((xi-2 == xf && yi-1 == yf) || (xi-2 == xf && yi+1 == yf) || (xi-1 == xf && yi+2 == yf)
      || (xi+1 == xf && yi+2 == yf) || (xi+2 == xf && yi+1 == yf) || (xi+2 == xf && yi-1 == yf)
      || (xi+1 == xf && yi-2 == yf) || (xi-1 == xf && yi-2 == yf)
      && (t.obtenerPieza(xf,yf).obtenerPieza().equals("VACIA") || t.obtenerPieza(xf,yf).obtenerPieza().equals("vacia"))){
        t.asignarPieza(t.obtenerPieza(xi,yi),xf,yf);
        Vacia v = new Vacia(true,xi,yi);
        t.asignarPieza(v,xi,yi);
        if(turno == true){
          turno = false;
        }else{
          turno = true;
        }
      }else{
        throw new MovimientoInvalidoExcepcion("No es un movimiento valido");
      }
    }else{
      throw new MovimientoInvalidoExcepcion("No es tu turno o no es tu pieza");
    }
    return turno;
  }
  /**
  *Metodo que te permite comer con tu caballo
  *@param t Es el tablero donde se movera la pieza
  *@param xi Posicion inicial en x
  *@param yi Posicion inicial en y
  *@param xf Posicion final en x
  *@param yf Posicion final en y
  *@param turno Turno que esta presente en el juego
  *@return boolean Es el nuevo turno si es que cambio, depende de si la pieza se mueve o no
  *@throws MovimientoInvalidoExcepcion Se lanza si no es posible hacer el movimiento
  */
  public boolean comer(Tablero t, int xi, int yi, int xf, int yf, boolean turno) throws MovimientoInvalidoExcepcion{
    if(t.obtenerPieza(xi,yi).obtenerColor() == turno){
      if((((xi-2 == xf && yi-1 == yf) || (xi-2 == xf && yi+1 == yf) || (xi-1 == xf && yi+2 == yf)
      || (xi+1 == xf && yi+2 == yf) || (xi+2 == xf && yi+1 == yf) || (xi+2 == xf && yi-1 == yf)
      || (xi+1 == xf && yi-2 == yf) || (xi-1 == xf && yi-2 == yf)))
      && t.obtenerPieza(xf,yf).obtenerColor() != t.obtenerPieza(xi,yi).obtenerColor()
      && !(t.obtenerPieza(xf,yf).obtenerPieza().equals("VACIA") || t.obtenerPieza(xf,yf).obtenerPieza().equals("vacia"))){
        t.asignarPieza(t.obtenerPieza(xi,yi),xf,yf);
        Vacia v = new Vacia(true,xi,yi);
        t.asignarPieza(v,xi,yi);
        if(turno == true){
          turno = false;
        }else{
          turno = true;
        }
      }else{
        throw new MovimientoInvalidoExcepcion("No es un movimiento valido");
      }
    }else{
      throw new MovimientoInvalidoExcepcion("No es tu turno o no es tu pieza");
    }
    return turno;
  }
  /**
  *Metodo que te permite ver si un movimiento es valido
  *@param t Es el tablero donde se movera la pieza
  *@param xi Posicion inicial en x
  *@param yi Posicion inicial en y
  *@param xf Posicion final en x
  *@param yf Posicion final en y
  *@param turno Turno que esta presente en el juego
  *@return boolean Te dice si es un movimiento valido
  */
  public boolean movimientoValido(Tablero t, int xi, int yi, int xf, int yf, boolean turno){
    if(t.obtenerPieza(xi,yi).obtenerColor() == turno){
      if((xi-2 == xf && yi-1 == yf) || (xi-2 == xf && yi+1 == yf) || (xi-1 == xf && yi+2 == yf)
      || (xi+1 == xf && yi+2 == yf) || (xi+2 == xf && yi+1 == yf) || (xi+2 == xf && yi-1 == yf)
      || (xi+1 == xf && yi-2 == yf) || (xi-1 == xf && yi-2 == yf)
      && (t.obtenerPieza(xf,yf).obtenerPieza().equals("VACIA") || t.obtenerPieza(xf,yf).obtenerPieza().equals("vacia"))){
        return true;
      }else{
        return false;
      }
    }else{
      return false;
    }
  }
}
