import java.util.Random;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.io.*;
import java.util.Date;
/**
*@author Miguel Torres Eric Giovanni
*@version 1.0
*/
public class Juego{
  /**
  *Metodo estatico para generar archivos
  @return String Es el nombre del archivo que genero
  @param nombre Es el nombre que tendra el archivo
  @param x Es una variable estatica para generar nombres
  */
  public static String generarArchivos(String nombre, int x){
    nombre+=x;
    x++;
    return nombre + ".txt";
  }
  public static void main(String nombres[]){

    //Variables para jugadores
    Jugador j1,j2;
    boolean color[] = new boolean[2];
    Random rand = new Random();
    color[0] = true;
    color[1] = false;

    //Variables para menu
    int opc,opc2;
    Scanner in = new Scanner(System.in);
    Scanner on = new Scanner(System.in);
    boolean salir = false, salir2 = false;

    //Variables para archivo
    int y = 1;
    int opc3;
    Scanner arch = new Scanner(System.in);
    boolean salir3 = false;

    //Variables para juego
    boolean salir4 = false;
    int opc4,xi,yi,xf,yf;
    Scanner inix = new Scanner(System.in);
    Scanner iniy = new Scanner(System.in);
    Scanner fnix = new Scanner(System.in);
    Scanner fniy = new Scanner(System.in);
    Scanner an = new Scanner(System.in);
    int caB = 2, caN = 2, peB = 6, peN = 6, toB = 2, toN = 2, daB = 1, daN = 1, reB = 1, reN = 1;
    boolean turno = true;
    Random rand1 = new Random();
    Random rand2 = new Random();
    Random rand3 = new Random();
    Random rand4 = new Random();

    if(nombres.length == 0){
      //Marca error cuando no hay nombres
      salir = true;
      salir2 = true;
      j1 = new Jugador("",true);
      j2 = new Jugador("",false);
      System.out.print("\033[H\033[2J");
      System.out.flush();
      System.out.println("Dame el numero de la partida que deseas, solo el numero: ");
      if(salir3 == true){
        salir3 = false;
      }
      while(!salir3){
        try{
          opc3 = arch.nextInt();
          String juego = "Partidas" + opc3 + ".txt";
          ObjectInputStream lector = null;
          try{
            lector = new ObjectInputStream(new FileInputStream(juego));
            Ganador gan;
            do {
              gan = (Ganador) lector.readObject();
              System.out.println(gan.toString());
            } while (gan != null);
          }catch(EOFException e){
            System.out.println("Fin de la lectura del archivo");
          }catch(ClassNotFoundException e){
            System.out.println("El objeto recuperado no es de la clase Ganador");
          }catch(IOException e){
            System.out.println("Error " + e);
          }finally{
            if(lector != null){
              System.out.println("Cerrando el archivo " + lector + ", adios :v");
              try{
                lector.close();
              }catch(IOException e){}
              salir3 = true;
            }else{
              System.out.println("No hay archivo abierto, adios :v");
              salir3 = true;
            }
          }
        }catch(InputMismatchException e){
          //ERRORES
          System.out.print("\033[H\033[2J");
          System.out.flush();
          System.out.println("Debes insertar un numero");
          on.next();
        }
      }
    }else if(nombres.length == 1){
      //Cuando es de un solo jugador
      j1 = new Jugador(nombres[0],color[0]);
      j2 = new Jugador("Computadora",color[1]);
    }else if(nombres.length == 2){
      //Cuando es de 2 jugadores
      j1 = new Jugador(nombres[0],color[0]);
      j2 = new Jugador(nombres[1],color[1]);
    }else{
      //Cuando hay 3 o mas jugadores
      j1 = new Jugador("",true);
      j2 = new Jugador("",false);
      System.out.print("\033[H\033[2J");
      System.out.flush();
      System.out.println("No puedes poner mas de 2 nombres");
      System.exit(0);
    }
    while(!salir){
      if(j1.obtenerTurno() == true){
        System.out.println(nombres[0] + ", mueves a las blancas");
        if(nombres.length == 2)
          System.out.println(nombres[1] + ", mueves a las negras");
        else
          System.out.println("Computadora, mueves a las negras");
      }
      else{
        System.out.println(nombres[0] + ", mueves a las negras");
        if(nombres.length == 2)
          System.out.println(nombres[1] + ", mueves a las blancas");
        else
          System.out.println("Computadora, mueves a las blancas");
      }
      //Menu para seleccionar que hacer
      try{
        System.out.println("Selecciona la opcion que deseas");
        System.out.println("1.Jugar");
        System.out.println("2.Salir del juego");
        opc = in.nextInt();
        switch(opc){
          //JUGAR
          case 1:
            System.out.print("\033[H\033[2J");
            System.out.flush();
            if(salir2 == true){
              salir2 = false;
            }
            while(!salir2){
              try{
                System.out.println("1.Nivel 1");
                System.out.println("2.Nivel 2");
                System.out.println("3.Nivel 3");
                System.out.println("4.Volver atras");
                System.out.println("5.Salir del juego");
                Tablero t = new Tablero();
                int cont = 0;
                opc2 = on.nextInt();
                switch(opc2){
                  //NIVEL 1
                  case 1:
                    System.out.print("\033[H\033[2J");
                    System.out.flush();
                    while(!salir4 && caB != 0 && caN != 0 && peB != 0 && peN != 0 && toB != 0 && toN != 0 && daB != 0 && daN != 0 && reB != 0 && reN != 0 && cont < 40){
                      try{
                        //INSTRUCCIONES DEL JUEGO
                        System.out.println("Empiezan las blancas (MAYUSCULAS), luego siguen las negras (minusculas)");
                        System.out.println("Debes decidir si moveras la pieza o comeras con la pieza");
                        System.out.println("Debes anotar las coordenadas x e y de la pieza que deseas mover");
                        System.out.println("Ya que lo hiciste, debes anotar las coordenadas x e y de a donde la moveras");
                        System.out.println("Si es un movimiento valido, movera la pieza");
                        System.out.println(t.toString());
                        if(turno == true){
                          System.out.println("Es turno de las blancas (MAYUSCULAS): " + j1.obtenerNombre());
                        }else{
                          System.out.println("Es turno de las negras (minusculas): " + j2.obtenerNombre());
                        }
                        //COSAS QUE PUEDES HACER
                        if(j2.obtenerNombre().equals("Computadora") && turno == false){
                          opc4 = 1;
                        }else{
                          System.out.println("¿Que deseas hacer?");
                          System.out.println("1. Mover");
                          System.out.println("2. Comer");
                          opc4 = an.nextInt();
                        }
                        switch(opc4){
                          //MOVER PIEZAS
                          case 1:
                            boolean aux = false;
                            while(!aux){
                              try{
                                if(j2.obtenerNombre().equals("Computadora") && turno == false){
                                  System.out.print("\033[H\033[2J");
                                  System.out.flush();
                                  System.out.println(t.toString());
                                  do {
                                    xi = rand1.nextInt(6);
                                    yi = rand2.nextInt(6);
                                    System.out.println(t.obtenerPieza(xi,yi).obtenerPieza());
                                    System.out.println("Me quedo aqui");
                                  } while (t.obtenerPieza(xi,yi).obtenerColor() == false && (t.obtenerPieza(xi,yi).obtenerPieza().equals("vacia") || t.obtenerPieza(xi,yi).obtenerPieza().equals("VACIA")));
                                  do {
                                    yf = -1;
                                    xf = 0;
                                    do {
                                      yf++;
                                      System.out.println(yf);
                                    } while (yf < 5 && !(t.obtenerPieza(xi,yi).movimientoValido(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor())));
                                    xf++;
                                    System.out.println(xf);
                                    System.out.println("Me quedo aqui2");
                                  } while ((t.obtenerPieza(xf,yf).obtenerPieza().equals("vacia") || t.obtenerPieza(xi,yi).obtenerPieza().equals("VACIA")) &&
                                  !(t.obtenerPieza(xi,yi).movimientoValido(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor())) && xf < 5);
                                  System.out.println(t.obtenerPieza(xi,yi).movimientoValido(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor()));
                                  boolean auxturn = turno;
                                  try{
                                    turno = t.obtenerPieza(xi,yi).mover(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor());
                                  }catch(ArrayIndexOutOfBoundsException e){
                                    System.out.println(e + ": Numero incorrecto");
                                  }catch(MovimientoInvalidoExcepcion e){
                                    System.out.println(e + ": Movimiento Invalido");
                                  }finally{
                                    aux = true;
                                  }
                                  if(auxturn != turno){
                                    cont++;
                                    aux = true;
                                  }
                                }else{
                                  System.out.print("\033[H\033[2J");
                                  System.out.flush();
                                  System.out.println(t.toString());
                                  System.out.println("Si deseas regresar, escribe numeros mayores a 5");
                                  System.out.println("Xi: ");
                                  xi = inix.nextInt();
                                  System.out.println("Yi: ");
                                  yi = iniy.nextInt();
                                  System.out.println("Xf: ");
                                  xf = fnix.nextInt();
                                  System.out.println("Yf: ");
                                  yf = fniy.nextInt();
                                  System.out.print("\033[H\033[2J");
                                  System.out.flush();
                                  boolean auxturn = turno;
                                  try{
                                    turno = t.obtenerPieza(xi,yi).mover(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor());
                                  }catch(ArrayIndexOutOfBoundsException e){
                                    System.out.println(e + ": Numero incorrecto");
                                  }catch(MovimientoInvalidoExcepcion e){
                                    System.out.println(e + ": Movimiento Invalido");
                                  }finally{
                                    aux = true;
                                  }
                                  if(auxturn != turno){
                                    cont++;
                                    aux = true;
                                  }
                                }
                              }catch(InputMismatchException e){
                                //ERRORES
                                System.out.print("\033[H\033[2J");
                                System.out.flush();
                                System.out.println("Debes insertar un numero");
                                inix.next();
                                iniy.next();
                                fnix.next();
                                fniy.next();
                              }
                            }
                            break;
                          //Comer
                          case 2:
                            System.out.print("\033[H\033[2J");
                            System.out.flush();
                            System.out.println(t.toString());
                            try{
                              System.out.print("\033[H\033[2J");
                              System.out.flush();
                              System.out.println(t.toString());
                              if(j2.obtenerNombre().equals("Computadora")){
                                System.out.println("La computadora no puede comer :v");
                              }else{
                                System.out.println("Xi: ");
                                xi = inix.nextInt();
                                System.out.println("Yi: ");
                                yi = iniy.nextInt();
                                System.out.println("Xf: ");
                                xf = fnix.nextInt();
                                System.out.println("Yf: ");
                                yf = fniy.nextInt();
                                System.out.print("\033[H\033[2J");
                                System.out.flush();
                                boolean auxturn = turno;
                                if(t.obtenerPieza(xf,yf).obtenerPieza().equals("peon") || t.obtenerPieza(xf,yf).obtenerPieza().equals("PEON")){
                                  if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                    peB--;
                                  }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                    peN--;
                                  }
                                }else if(t.obtenerPieza(xf,yf).obtenerPieza().equals("dama") || t.obtenerPieza(xf,yf).obtenerPieza().equals("DAMA")){
                                  if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                    daB--;
                                  }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                    daN--;
                                  }
                                }else if(t.obtenerPieza(xf,yf).obtenerPieza().equals("rey") || t.obtenerPieza(xf,yf).obtenerPieza().equals("REY")){
                                  if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                    reB--;
                                  }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                    reN--;
                                  }
                                }else if(t.obtenerPieza(xf,yf).obtenerPieza().equals("caballo") || t.obtenerPieza(xf,yf).obtenerPieza().equals("CABALLO")){
                                  if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                    caB--;
                                  }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                    caN--;
                                  }
                                }else if(t.obtenerPieza(xf,yf).obtenerPieza().equals("torre") || t.obtenerPieza(xf,yf).obtenerPieza().equals("TORRE")){
                                  if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                    toB--;
                                  }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                    toN--;
                                  }
                                }
                                try{
                                  turno = t.obtenerPieza(xi,yi).comer(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor());
                                }catch(ArrayIndexOutOfBoundsException e){
                                  System.out.println(e + "Numero incorrecto");
                                }catch(MovimientoInvalidoExcepcion e){
                                  System.out.println(e + ": Movimiento Invalido");
                                }finally{
                                  aux = true;
                                }
                                if(auxturn != turno){
                                  cont++;
                                  aux = true;
                                }
                              }
                            }catch(InputMismatchException e){
                              //ERRORES
                              System.out.print("\033[H\033[2J");
                              System.out.flush();
                              System.out.println("Debes insertar un numero");
                              inix.next();
                              iniy.next();
                              fnix.next();
                              fniy.next();
                            }
                            break;
                          //Otra cosa
                          default:
                            System.out.print("\033[H\033[2J");
                            System.out.flush();
                            System.out.println("Solo numeros entre 1 y 2");
                            System.out.println();
                            break;
                        }
                      }catch(InputMismatchException e){
                        //ERRORES
                        System.out.print("\033[H\033[2J");
                        System.out.flush();
                        System.out.println("Debes insertar un numero");
                        an.next();
                      }
                    }
                    if(!j2.obtenerNombre().equals("Computadora")){
                      if(cont == 40){
                        ObjectOutputStream escritor = null;
                        try{
                          String juego = "Partidas";
                          Date fecha = new Date();
                          escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                          escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Empate",fecha));
                        }catch(NotSerializableException e){
                          System.out.println("Error en la grabacion, objeto no serializable");
                        }catch(IOException e){
                          System.out.println("Error en la grabacion: " + e);
                        }finally{
                          if(escritor != null){
                            System.out.println("Cerrando el archivo " + escritor);
                            try{
                              escritor.close();
                            }catch(IOException e){}
                          }else{
                            System.out.println("No hay ningun archivo abierto.");
                          }
                        }
                      }else if(peN == 0 || caN == 0 || daN == 0 || reN == 0 || toN == 0){
                        ObjectOutputStream escritor = null;
                        try{
                          String juego = "Partidas";
                          Date fecha = new Date();
                          escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                          escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Ganar",fecha));
                        }catch(NotSerializableException e){
                          System.out.println("Error en la grabacion, objeto no serializable");
                        }catch(IOException e){
                          System.out.println("Error en la grabacion: " + e);
                        }finally{
                          y++;
                          if(escritor != null){
                            System.out.println("Cerrando el archivo " + escritor);
                            try{
                              escritor.close();
                            }catch(IOException e){}
                          }else{
                            System.out.println("No hay ningun archivo abierto.");
                          }
                        }
                      }else if(peB == 0 || caB == 0 || daB == 0 || reB == 0 || toB == 0){
                        ObjectOutputStream escritor = null;
                        try{
                          String juego = "Partidas";
                          Date fecha = new Date();
                          escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                          escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Perder",fecha));
                        }catch(NotSerializableException e){
                          System.out.println("Error en la grabacion, objeto no serializable");
                        }catch(IOException e){
                          System.out.println("Error en la grabacion: " + e);
                        }finally{
                          y++;
                          if(escritor != null){
                            System.out.println("Cerrando el archivo " + escritor);
                            try{
                              escritor.close();
                            }catch(IOException e){}
                          }else{
                            System.out.println("No hay ningun archivo abierto.");
                          }
                        }
                      }
                    }else{
                      if(cont == 40 || peB == 0 || caB == 0 || daB == 0 || reB == 0 || toB == 0){
                        ObjectOutputStream escritor = null;
                        try{
                          String juego = "Partidas";
                          Date fecha = new Date();
                          escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                          escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Perder",fecha));
                        }catch(NotSerializableException e){
                          System.out.println("Error en la grabacion, objeto no serializable");
                        }catch(IOException e){
                          System.out.println("Error en la grabacion: " + e);
                        }finally{
                          y++;
                          if(escritor != null){
                            System.out.println("Cerrando el archivo " + escritor);
                            try{
                              escritor.close();
                            }catch(IOException e){}
                          }else{
                            System.out.println("No hay ningun archivo abierto.");
                          }
                        }
                      }else if(peN == 0 || caN == 0 || daN == 0 || reN == 0 || toN == 0){
                        ObjectOutputStream escritor = null;
                        try{
                          String juego = "Partidas";
                          Date fecha = new Date();
                          escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                          escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Ganar",fecha));
                        }catch(NotSerializableException e){
                          System.out.println("Error en la grabacion, objeto no serializable");
                        }catch(IOException e){
                          System.out.println("Error en la grabacion: " + e);
                        }finally{
                          y++;
                          if(escritor != null){
                            System.out.println("Cerrando el archivo " + escritor);
                            try{
                              escritor.close();
                            }catch(IOException e){}
                          }else{
                            System.out.println("No hay ningun archivo abierto.");
                          }
                        }
                      }
                    }
                    System.out.println("Gracias por jugar, nos vemos");
                    salir = true;
                    salir2 = true;
                    break;
                  //NIVEL 2
                  case 2:
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
                  while(!salir4 && caB != 0 && caN != 0 && peB != 0 && peN != 0 && toB != 0 && toN != 0 && daB != 0 && daN != 0 && reB != 0 && reN != 0 && cont < 80){
                    try{
                      //INSTRUCCIONES DEL JUEGO
                      System.out.println("Empiezan las blancas (MAYUSCULAS), luego siguen las negras (minusculas)");
                      System.out.println("Debes decidir si moveras la pieza o comeras con la pieza");
                      System.out.println("Debes anotar las coordenadas x e y de la pieza que deseas mover");
                      System.out.println("Ya que lo hiciste, debes anotar las coordenadas x e y de a donde la moveras");
                      System.out.println("Si es un movimiento valido, movera la pieza");
                      System.out.println(t.toString());
                      if(turno == true){
                        System.out.println("Es turno de las blancas (MAYUSCULAS): " + j1.obtenerNombre());
                      }else{
                        System.out.println("Es turno de las negras (minusculas): " + j2.obtenerNombre());
                      }
                      //COSAS QUE PUEDES HACER
                      if(j2.obtenerNombre().equals("Computadora") && turno == false){
                        opc4 = 1;
                      }else{
                        System.out.println("¿Que deseas hacer?");
                        System.out.println("1. Mover");
                        System.out.println("2. Comer");
                        opc4 = an.nextInt();
                      }
                      switch(opc4){
                        //MOVER PIEZAS
                        case 1:
                          boolean aux = false;
                          while(!aux){
                            try{
                              if(j2.obtenerNombre().equals("Computadora") && turno == false){
                                System.out.print("\033[H\033[2J");
                                System.out.flush();
                                System.out.println(t.toString());
                                do {
                                  xi = rand1.nextInt(6);
                                  yi = rand2.nextInt(6);
                                  System.out.println(t.obtenerPieza(xi,yi).obtenerPieza());
                                  System.out.println("Me quedo aqui");
                                } while (t.obtenerPieza(xi,yi).obtenerColor() == false && (t.obtenerPieza(xi,yi).obtenerPieza().equals("vacia") || t.obtenerPieza(xi,yi).obtenerPieza().equals("VACIA")));
                                do {
                                  yf = -1;
                                  xf = 0;
                                  do {
                                    yf++;
                                    System.out.println(yf);
                                  } while (yf < 5 && !(t.obtenerPieza(xi,yi).movimientoValido(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor())));
                                  xf++;
                                  System.out.println(xf);
                                  System.out.println("Me quedo aqui2");
                                } while ((t.obtenerPieza(xf,yf).obtenerPieza().equals("vacia") || t.obtenerPieza(xi,yi).obtenerPieza().equals("VACIA")) &&
                                !(t.obtenerPieza(xi,yi).movimientoValido(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor())) && xf < 5);
                                System.out.println(t.obtenerPieza(xi,yi).movimientoValido(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor()));
                                boolean auxturn = turno;
                                try{
                                  turno = t.obtenerPieza(xi,yi).mover(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor());
                                }catch(ArrayIndexOutOfBoundsException e){
                                  System.out.println(e + ": Numero incorrecto");
                                }catch(MovimientoInvalidoExcepcion e){
                                  System.out.println(e + ": Movimiento Invalido");
                                }finally{
                                  aux = true;
                                }
                                if(auxturn != turno){
                                  cont++;
                                  aux = true;
                                }
                              }else{
                                System.out.print("\033[H\033[2J");
                                System.out.flush();
                                System.out.println(t.toString());
                                System.out.println("Si deseas regresar, escribe numeros mayores a 5");
                                System.out.println("Xi: ");
                                xi = inix.nextInt();
                                System.out.println("Yi: ");
                                yi = iniy.nextInt();
                                System.out.println("Xf: ");
                                xf = fnix.nextInt();
                                System.out.println("Yf: ");
                                yf = fniy.nextInt();
                                System.out.print("\033[H\033[2J");
                                System.out.flush();
                                boolean auxturn = turno;
                                try{
                                  turno = t.obtenerPieza(xi,yi).mover(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor());
                                }catch(ArrayIndexOutOfBoundsException e){
                                  System.out.println(e + ": Numero incorrecto");
                                }catch(MovimientoInvalidoExcepcion e){
                                  System.out.println(e + ": Movimiento Invalido");
                                }finally{
                                  aux = true;
                                }
                                if(auxturn != turno){
                                  cont++;
                                  aux = true;
                                }
                              }
                            }catch(InputMismatchException e){
                              //ERRORES
                              System.out.print("\033[H\033[2J");
                              System.out.flush();
                              System.out.println("Debes insertar un numero");
                              inix.next();
                              iniy.next();
                              fnix.next();
                              fniy.next();
                            }
                          }
                          break;
                        //Comer
                        case 2:
                          System.out.print("\033[H\033[2J");
                          System.out.flush();
                          System.out.println(t.toString());
                          try{
                            System.out.print("\033[H\033[2J");
                            System.out.flush();
                            System.out.println(t.toString());
                            if(j2.obtenerNombre().equals("Computadora")){
                              System.out.println("La computadora no puede comer :v");
                            }else{
                              System.out.println("Xi: ");
                              xi = inix.nextInt();
                              System.out.println("Yi: ");
                              yi = iniy.nextInt();
                              System.out.println("Xf: ");
                              xf = fnix.nextInt();
                              System.out.println("Yf: ");
                              yf = fniy.nextInt();
                              System.out.print("\033[H\033[2J");
                              System.out.flush();
                              boolean auxturn = turno;
                              if(t.obtenerPieza(xf,yf).obtenerPieza().equals("peon") || t.obtenerPieza(xf,yf).obtenerPieza().equals("PEON")){
                                if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                  peB--;
                                }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                  peN--;
                                }
                              }else if(t.obtenerPieza(xf,yf).obtenerPieza().equals("dama") || t.obtenerPieza(xf,yf).obtenerPieza().equals("DAMA")){
                                if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                  daB--;
                                }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                  daN--;
                                }
                              }else if(t.obtenerPieza(xf,yf).obtenerPieza().equals("rey") || t.obtenerPieza(xf,yf).obtenerPieza().equals("REY")){
                                if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                  reB--;
                                }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                  reN--;
                                }
                              }else if(t.obtenerPieza(xf,yf).obtenerPieza().equals("caballo") || t.obtenerPieza(xf,yf).obtenerPieza().equals("CABALLO")){
                                if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                  caB--;
                                }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                  caN--;
                                }
                              }else if(t.obtenerPieza(xf,yf).obtenerPieza().equals("torre") || t.obtenerPieza(xf,yf).obtenerPieza().equals("TORRE")){
                                if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                  toB--;
                                }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                  toN--;
                                }
                              }
                              try{
                                turno = t.obtenerPieza(xi,yi).comer(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor());
                              }catch(ArrayIndexOutOfBoundsException e){
                                System.out.println(e + "Numero incorrecto");
                              }catch(MovimientoInvalidoExcepcion e){
                                System.out.println(e + ": Movimiento Invalido");
                              }finally{
                                aux = true;
                              }
                              if(auxturn != turno){
                                cont++;
                                aux = true;
                              }
                            }
                          }catch(InputMismatchException e){
                            //ERRORES
                            System.out.print("\033[H\033[2J");
                            System.out.flush();
                            System.out.println("Debes insertar un numero");
                            inix.next();
                            iniy.next();
                            fnix.next();
                            fniy.next();
                          }
                          break;
                        //Otra cosa
                        default:
                          System.out.print("\033[H\033[2J");
                          System.out.flush();
                          System.out.println("Solo numeros entre 1 y 2");
                          System.out.println();
                          break;
                      }
                    }catch(InputMismatchException e){
                      //ERRORES
                      System.out.print("\033[H\033[2J");
                      System.out.flush();
                      System.out.println("Debes insertar un numero");
                      an.next();
                    }
                  }
                  if(!j2.obtenerNombre().equals("Computadora")){
                    if(cont == 80){
                      ObjectOutputStream escritor = null;
                      try{
                        String juego = "Partidas";
                        Date fecha = new Date();
                        escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                        escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Empate",fecha));
                      }catch(NotSerializableException e){
                        System.out.println("Error en la grabacion, objeto no serializable");
                      }catch(IOException e){
                        System.out.println("Error en la grabacion: " + e);
                      }finally{
                        y++;
                        if(escritor != null){
                          System.out.println("Cerrando el archivo " + escritor);
                          try{
                            escritor.close();
                          }catch(IOException e){}
                        }else{
                          System.out.println("No hay ningun archivo abierto.");
                        }
                      }
                    }else if(peN == 0 || caN == 0 || daN == 0 || reN == 0 || toN == 0){
                      ObjectOutputStream escritor = null;
                      try{
                        String juego = "Partidas";
                        Date fecha = new Date();
                        escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                        escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Ganar",fecha));
                      }catch(NotSerializableException e){
                        System.out.println("Error en la grabacion, objeto no serializable");
                      }catch(IOException e){
                        System.out.println("Error en la grabacion: " + e);
                      }finally{
                        y++;
                        if(escritor != null){
                          System.out.println("Cerrando el archivo " + escritor);
                          try{
                            escritor.close();
                          }catch(IOException e){}
                        }else{
                          System.out.println("No hay ningun archivo abierto.");
                        }
                      }
                    }else if(peB == 0 || caB == 0 || daB == 0 || reB == 0 || toB == 0){
                      ObjectOutputStream escritor = null;
                      try{
                        String juego = "Partidas";
                        Date fecha = new Date();
                        escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                        escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Perder",fecha));
                      }catch(NotSerializableException e){
                        System.out.println("Error en la grabacion, objeto no serializable");
                      }catch(IOException e){
                        System.out.println("Error en la grabacion: " + e);
                      }finally{
                        y++;
                        if(escritor != null){
                          System.out.println("Cerrando el archivo " + escritor);
                          try{
                            escritor.close();
                          }catch(IOException e){}
                        }else{
                          System.out.println("No hay ningun archivo abierto.");
                        }
                      }
                    }
                  }else{
                    if(cont == 80 || peB == 0 || caB == 0 || daB == 0 || reB == 0 || toB == 0){
                      ObjectOutputStream escritor = null;
                      try{
                        String juego = "Partidas";
                        Date fecha = new Date();
                        escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                        escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Perder",fecha));
                      }catch(NotSerializableException e){
                        System.out.println("Error en la grabacion, objeto no serializable");
                      }catch(IOException e){
                        System.out.println("Error en la grabacion: " + e);
                      }finally{
                        y++;
                        if(escritor != null){
                          System.out.println("Cerrando el archivo " + escritor);
                          try{
                            escritor.close();
                          }catch(IOException e){}
                        }else{
                          System.out.println("No hay ningun archivo abierto.");
                        }
                      }
                    }else if(peN == 0 || caN == 0 || daN == 0 || reN == 0 || toN == 0){
                      ObjectOutputStream escritor = null;
                      try{
                        String juego = "Partidas";
                        Date fecha = new Date();
                        escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                        escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Ganar",fecha));
                      }catch(NotSerializableException e){
                        System.out.println("Error en la grabacion, objeto no serializable");
                      }catch(IOException e){
                        System.out.println("Error en la grabacion: " + e);
                      }finally{
                        y++;
                        if(escritor != null){
                          System.out.println("Cerrando el archivo " + escritor);
                          try{
                            escritor.close();
                          }catch(IOException e){}
                        }else{
                          System.out.println("No hay ningun archivo abierto.");
                        }
                      }
                    }
                  }
                  System.out.println("Gracias por jugar, nos vemos");
                  salir = true;
                  salir2 = true;
                  break;
                  //NIVEL 3
                  case 3:
                  System.out.print("\033[H\033[2J");
                  System.out.flush();
                  while(!salir4 && caB != 0 && caN != 0 && peB != 0 && peN != 0 && toB != 0 && toN != 0 && daB != 0 && daN != 0 && reB != 0 && reN != 0 && cont < 200){
                    try{
                      //INSTRUCCIONES DEL JUEGO
                      System.out.println("Empiezan las blancas (MAYUSCULAS), luego siguen las negras (minusculas)");
                      System.out.println("Debes decidir si moveras la pieza o comeras con la pieza");
                      System.out.println("Debes anotar las coordenadas x e y de la pieza que deseas mover");
                      System.out.println("Ya que lo hiciste, debes anotar las coordenadas x e y de a donde la moveras");
                      System.out.println("Si es un movimiento valido, movera la pieza");
                      System.out.println(t.toString());
                      if(turno == true){
                        System.out.println("Es turno de las blancas (MAYUSCULAS): " + j1.obtenerNombre());
                      }else{
                        System.out.println("Es turno de las negras (minusculas): " + j2.obtenerNombre());
                      }
                      //COSAS QUE PUEDES HACER
                      if(j2.obtenerNombre().equals("Computadora") && turno == false){
                        opc4 = 1;
                      }else{
                        System.out.println("¿Que deseas hacer?");
                        System.out.println("1. Mover");
                        System.out.println("2. Comer");
                        opc4 = an.nextInt();
                      }
                      switch(opc4){
                        //MOVER PIEZAS
                        case 1:
                          boolean aux = false;
                          while(!aux){
                            try{
                              if(j2.obtenerNombre().equals("Computadora") && turno == false){
                                System.out.print("\033[H\033[2J");
                                System.out.flush();
                                System.out.println(t.toString());
                                do {
                                  xi = rand1.nextInt(6);
                                  yi = rand2.nextInt(6);
                                  System.out.println(t.obtenerPieza(xi,yi).obtenerPieza());
                                  System.out.println("Me quedo aqui");
                                } while (t.obtenerPieza(xi,yi).obtenerColor() == false && (t.obtenerPieza(xi,yi).obtenerPieza().equals("vacia") || t.obtenerPieza(xi,yi).obtenerPieza().equals("VACIA")));
                                do {
                                  yf = -1;
                                  xf = 0;
                                  do {
                                    yf++;
                                    System.out.println(yf);
                                  } while (yf < 5 && !(t.obtenerPieza(xi,yi).movimientoValido(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor())));
                                  xf++;
                                  System.out.println(xf);
                                  System.out.println("Me quedo aqui2");
                                } while ((t.obtenerPieza(xf,yf).obtenerPieza().equals("vacia") || t.obtenerPieza(xi,yi).obtenerPieza().equals("VACIA")) &&
                                !(t.obtenerPieza(xi,yi).movimientoValido(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor())) && xf < 5);
                                System.out.println(t.obtenerPieza(xi,yi).movimientoValido(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor()));
                                boolean auxturn = turno;
                                try{
                                  turno = t.obtenerPieza(xi,yi).mover(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor());
                                }catch(ArrayIndexOutOfBoundsException e){
                                  System.out.println(e + ": Numero incorrecto");
                                }catch(MovimientoInvalidoExcepcion e){
                                  System.out.println(e + ": Movimiento Invalido");
                                }finally{
                                  aux = true;
                                }
                                if(auxturn != turno){
                                  cont++;
                                  aux = true;
                                }
                              }else{
                                System.out.print("\033[H\033[2J");
                                System.out.flush();
                                System.out.println(t.toString());
                                System.out.println("Si deseas regresar, escribe numeros mayores a 5");
                                System.out.println("Xi: ");
                                xi = inix.nextInt();
                                System.out.println("Yi: ");
                                yi = iniy.nextInt();
                                System.out.println("Xf: ");
                                xf = fnix.nextInt();
                                System.out.println("Yf: ");
                                yf = fniy.nextInt();
                                System.out.print("\033[H\033[2J");
                                System.out.flush();
                                boolean auxturn = turno;
                                try{
                                  turno = t.obtenerPieza(xi,yi).mover(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor());
                                }catch(ArrayIndexOutOfBoundsException e){
                                  System.out.println(e + ": Numero incorrecto");
                                }catch(MovimientoInvalidoExcepcion e){
                                  System.out.println(e + ": Movimiento Invalido");
                                }finally{
                                  aux = true;
                                }
                                if(auxturn != turno){
                                  cont++;
                                  aux = true;
                                }
                              }
                            }catch(InputMismatchException e){
                              //ERRORES
                              System.out.print("\033[H\033[2J");
                              System.out.flush();
                              System.out.println("Debes insertar un numero");
                              inix.next();
                              iniy.next();
                              fnix.next();
                              fniy.next();
                            }
                          }
                          break;
                        //Comer
                        case 2:
                          System.out.print("\033[H\033[2J");
                          System.out.flush();
                          System.out.println(t.toString());
                          try{
                            System.out.print("\033[H\033[2J");
                            System.out.flush();
                            System.out.println(t.toString());
                            if(j2.obtenerNombre().equals("Computadora")){
                              System.out.println("La computadora no puede comer :v");
                            }else{
                              System.out.println("Xi: ");
                              xi = inix.nextInt();
                              System.out.println("Yi: ");
                              yi = iniy.nextInt();
                              System.out.println("Xf: ");
                              xf = fnix.nextInt();
                              System.out.println("Yf: ");
                              yf = fniy.nextInt();
                              System.out.print("\033[H\033[2J");
                              System.out.flush();
                              boolean auxturn = turno;
                              if(t.obtenerPieza(xf,yf).obtenerPieza().equals("peon") || t.obtenerPieza(xf,yf).obtenerPieza().equals("PEON")){
                                if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                  peB--;
                                }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                  peN--;
                                }
                              }else if(t.obtenerPieza(xf,yf).obtenerPieza().equals("dama") || t.obtenerPieza(xf,yf).obtenerPieza().equals("DAMA")){
                                if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                  daB--;
                                }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                  daN--;
                                }
                              }else if(t.obtenerPieza(xf,yf).obtenerPieza().equals("rey") || t.obtenerPieza(xf,yf).obtenerPieza().equals("REY")){
                                if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                  reB--;
                                }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                  reN--;
                                }
                              }else if(t.obtenerPieza(xf,yf).obtenerPieza().equals("caballo") || t.obtenerPieza(xf,yf).obtenerPieza().equals("CABALLO")){
                                if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                  caB--;
                                }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                  caN--;
                                }
                              }else if(t.obtenerPieza(xf,yf).obtenerPieza().equals("torre") || t.obtenerPieza(xf,yf).obtenerPieza().equals("TORRE")){
                                if(t.obtenerPieza(xf,yf).obtenerColor() == true && turno != t.obtenerPieza(xf,yf).obtenerColor()){
                                  toB--;
                                }else if(t.obtenerPieza(xf,yf).obtenerColor() != turno){
                                  toN--;
                                }
                              }
                              try{
                                turno = t.obtenerPieza(xi,yi).comer(t,xi,yi,xf,yf,t.obtenerPieza(xi,yi).obtenerColor());
                              }catch(ArrayIndexOutOfBoundsException e){
                                System.out.println(e + "Numero incorrecto");
                              }catch(MovimientoInvalidoExcepcion e){
                                System.out.println(e + ": Movimiento Invalido");
                              }finally{
                                aux = true;
                              }
                              if(auxturn != turno){
                                cont++;
                                aux = true;
                              }
                            }
                          }catch(InputMismatchException e){
                            //ERRORES
                            System.out.print("\033[H\033[2J");
                            System.out.flush();
                            System.out.println("Debes insertar un numero");
                            inix.next();
                            iniy.next();
                            fnix.next();
                            fniy.next();
                          }
                          break;
                        //Otra cosa
                        default:
                          System.out.print("\033[H\033[2J");
                          System.out.flush();
                          System.out.println("Solo numeros entre 1 y 2");
                          System.out.println();
                          break;
                      }
                    }catch(InputMismatchException e){
                      //ERRORES
                      System.out.print("\033[H\033[2J");
                      System.out.flush();
                      System.out.println("Debes insertar un numero");
                      an.next();
                    }
                  }
                  if(!j2.obtenerNombre().equals("Computadora")){
                    if(cont == 200){
                      ObjectOutputStream escritor = null;
                      try{
                        String juego = "Partidas";
                        Date fecha = new Date();
                        escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                        escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Empate",fecha));
                      }catch(NotSerializableException e){
                        System.out.println("Error en la grabacion, objeto no serializable");
                      }catch(IOException e){
                        System.out.println("Error en la grabacion: " + e);
                      }finally{
                        y++;
                        if(escritor != null){
                          System.out.println("Cerrando el archivo " + escritor);
                          try{
                            escritor.close();
                          }catch(IOException e){}
                        }else{
                          System.out.println("No hay ningun archivo abierto.");
                        }
                      }
                    }else if(peN == 0 || caN == 0 || daN == 0 || reN == 0 || toN == 0){
                      ObjectOutputStream escritor = null;
                      try{
                        String juego = "Partidas";
                        Date fecha = new Date();
                        escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                        escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Ganar",fecha));
                      }catch(NotSerializableException e){
                        System.out.println("Error en la grabacion, objeto no serializable");
                      }catch(IOException e){
                        System.out.println("Error en la grabacion: " + e);
                      }finally{
                        y++;
                        if(escritor != null){
                          System.out.println("Cerrando el archivo " + escritor);
                          try{
                            escritor.close();
                          }catch(IOException e){}
                        }else{
                          System.out.println("No hay ningun archivo abierto.");
                        }
                      }
                    }else if(peB == 0 || caB == 0 || daB == 0 || reB == 0 || toB == 0){
                      ObjectOutputStream escritor = null;
                      try{
                        String juego = "Partidas";
                        Date fecha = new Date();
                        escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                        escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Perder",fecha));
                      }catch(NotSerializableException e){
                        System.out.println("Error en la grabacion, objeto no serializable");
                      }catch(IOException e){
                        System.out.println("Error en la grabacion: " + e);
                      }finally{
                        y++;
                        if(escritor != null){
                          System.out.println("Cerrando el archivo " + escritor);
                          try{
                            escritor.close();
                          }catch(IOException e){}
                        }else{
                          System.out.println("No hay ningun archivo abierto.");
                        }
                      }
                    }
                  }else{
                    if(cont == 200 || peB == 0 || caB == 0 || daB == 0 || reB == 0 || toB == 0){
                      ObjectOutputStream escritor = null;
                      try{
                        String juego = "Partidas";
                        Date fecha = new Date();
                        escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                        escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Perder",fecha));
                      }catch(NotSerializableException e){
                        System.out.println("Error en la grabacion, objeto no serializable");
                      }catch(IOException e){
                        System.out.println("Error en la grabacion: " + e);
                      }finally{
                        y++;
                        if(escritor != null){
                          System.out.println("Cerrando el archivo " + escritor);
                          try{
                            escritor.close();
                          }catch(IOException e){}
                        }else{
                          System.out.println("No hay ningun archivo abierto.");
                        }
                      }
                    }else if(peN == 0 || caN == 0 || daN == 0 || reN == 0 || toN == 0){
                      ObjectOutputStream escritor = null;
                      try{
                        String juego = "Partidas";
                        Date fecha = new Date();
                        escritor = new ObjectOutputStream(new FileOutputStream(generarArchivos(juego,y)));
                        escritor.writeObject(new Ganador(j1.obtenerNombre(),j2.obtenerNombre(),"Ganar",fecha));
                      }catch(NotSerializableException e){
                        System.out.println("Error en la grabacion, objeto no serializable");
                      }catch(IOException e){
                        System.out.println("Error en la grabacion: " + e);
                      }finally{
                        y++;
                        if(escritor != null){
                          System.out.println("Cerrando el archivo " + escritor);
                          try{
                            escritor.close();
                          }catch(IOException e){}
                        }else{
                          System.out.println("No hay ningun archivo abierto.");
                        }
                      }
                    }
                  }
                  System.out.println("Gracias por jugar, nos vemos");
                  salir = true;
                  salir2 = true;
                  break;
                  //REGRESAR
                  case 4:
                    System.out.print("\033[H\033[2J");
                    System.out.flush();
                    salir2 = true;
                    opc2 = 6;
                    break;
                  //SALIR
                  case 5:
                    System.out.print("\033[H\033[2J");
                    System.out.flush();
                    System.out.println("Gracias por jugar, nos vemos");
                    salir = true;
                    salir2 = true;
                    break;
                  //CUALQUIER OTRA COSA
                  default:
                    System.out.print("\033[H\033[2J");
                    System.out.flush();
                    System.out.println("Solo numeros entre 1 y 5");
                    System.out.println();
                    break;
                }
              }catch(InputMismatchException e){
                //ERRORES
                System.out.print("\033[H\033[2J");
                System.out.flush();
                System.out.println("Debes insertar un numero");
                on.next();
              }
            }
            break;
          //SALIR
          case 2:
            System.out.print("\033[H\033[2J");
            System.out.flush();
            System.out.println("Gracias por jugar, nos vemos!!");
            salir = true;
            break;
          //CUALQUIER OTRA COSA
          default:
            System.out.print("\033[H\033[2J");
            System.out.flush();
            System.out.println("Solo numeros entre 1 y 2");
            System.out.println();
        }
      }catch (InputMismatchException e){
        //ERRORES
        System.out.print("\033[H\033[2J");
        System.out.flush();
        System.out.println("Debes insertar un numero");
        System.out.println();
        in.next();
      }
    }
  }
}
