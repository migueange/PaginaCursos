import java.io.*;
import java.util.Date;
import java.text.SimpleDateFormat;
/**
*@author Miguel Torres Eric Giovanni
*@version 1.0
*/
public class Ganador implements Serializable{
  private String nombre1,nombre2,ganador;
  private Date fechaActual;
  /**
  *Constructor con parametros
  *@param nom1 Es el nombre del jugador 1
  *@param nom2 Es el nombre del jugador 2
  *@param gan Es el resultado del juego
  *@param fecha Es la fecha en que gano
  */
  public Ganador(String nom1, String nom2, String gan, Date fecha){
    nombre1 = nom1;
    nombre2 = nom2;
    ganador = gan;
    fechaActual = fecha;
  }
  /**
  *Metodo que te permite obtener la fecha del juego
  *@return Date Es la fecha del juego
  */
  public Date obtenerFecha(){
    return fechaActual;
  }
  /**
  *Metodo que te permite obtener el nombre del jugador 1
  *@return String Es el nombre del jugador 1
  */
  public String obtenerNombre1(){
    return nombre1;
  }
  /**
  *Metodo que te permite obtener el nombre del jugador 2
  *@return String Es el nombre del jugador 2
  */
  public String obtenerNombre2(){
    return nombre2;
  }
  /**
  *Metodo que te permite obtener el resultado de la partida
  *@return String Es el resultado de la partida
  */
  public String obtenerGanador(){
    return ganador;
  }
  /**
  *Metodo toString de la clase
  *@return String Te devuelve el enfrentamiento y quien gano
  */
  /**
  *Metodo que te permite asignar la fecha del juego
  *@param fecha Es la fecha del juego que asignaras
  */
  public void asignarFecha(Date fecha){
    fechaActual = fecha;
  }
  /**
  *Metodo que te permite asignar el nombre del jugador 1
  *@param nom1 Es el nombre del jugador 1 que asignaras
  */
  public void asignarNombre1(String nom1){
    nombre1 = nom1;
  }
  /**
  *Metodo que te permite asignar el nombre del jugador 2
  *@param nom2 Es el nombre del jugador 2 que asignaras
  */
  public void asignarNombre2(String nom2){
    nombre2 = nom2;
  }
  /**
  *Metodo que te permite asignar el ganador del juego
  *@param gan Es el ganador del juego que asignaras
  */
  public void asignarGanador(String gan){
    ganador = gan;
  }
  /*
  *Metodo que te convierte en String quien gano, quien perdio o si fue empate
  @return String Es la cadena de texto que enviara
  **/
  public String toString(){
    if(obtenerGanador().equals("Ganar")){
      return obtenerNombre1() + " vs " + obtenerNombre2() + ": El resultado fue que gano " + obtenerNombre1() + " en la fecha: " + new SimpleDateFormat("dd-MM-yyyy").format(fechaActual);
    }else if(obtenerGanador().equals("Perder")){
      return obtenerNombre1() + " vs " + obtenerNombre2() + ": El resultado fue que gano " + obtenerNombre2() + " en la fecha: " + new SimpleDateFormat("dd-MM-yyyy").format(fechaActual);
    }else{
      return obtenerNombre1() + " vs " + obtenerNombre2() + ": El resultado fue empate " + " en la fecha: " + new SimpleDateFormat("dd-MM-yyyy").format(fechaActual);
    }
  }
}
