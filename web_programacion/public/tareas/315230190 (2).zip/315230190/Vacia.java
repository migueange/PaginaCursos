/**
*@author Miguel Torres Eric Giovanni
*@version 1.0
*/
public class Vacia extends Piezas{
  /**
  *Constructor con parametros
  *@param col Es el color de la pieza, si es true será blanca, si es false será negra
  *@param xini Es la posicion inicial en x
  *@param yini Es la posicion inicial en y
  */
  public Vacia(boolean col, int xini, int yini){
    super("vacia", col, xini, yini);
  }
  /**
  *Metodo que te prohibe mover la pieza vacia
  *@param t Es el tablero donde se movera la pieza
  *@param xi Posicion inicial en x
  *@param yi Posicion inicial en y
  *@param xf Posicion final en x
  *@param yf Posicion final en y
  *@param turno Turno que esta presente en el juego
  *@return boolean Es el nuevo turno si es que cambio, depende de si la pieza se mueve o no
  */
  public boolean mover(Tablero t, int xi, int yi, int xf, int yf, boolean turno){
    System.out.println("No puedes mover esta pieza");
    return turno;
  }
  /**
  *Metodo que te prohibe mover la pieza vacia
  *@param t Es el tablero donde se movera la pieza
  *@param xini Posicion inicial en x
  *@param yini Posicion inicial en y
  *@param xf Posicion final en x
  *@param yf Posicion final en y
  *@param turno Turno que esta presente en el juego
  *@return boolean Es el nuevo turno si es que cambio, depende de si la pieza se mueve o no
  */
  public boolean comer(Tablero t, int xini, int yini, int xf, int yf, boolean turno){
    System.out.println("No puedes comer con esta pieza");
    return turno;
  }
  /**
  *Metodo que te permite ver si un movimiento es valido
  *@param t Es el tablero donde se movera la pieza
  *@param xi Posicion inicial en x
  *@param yi Posicion inicial en y
  *@param xf Posicion final en x
  *@param yf Posicion final en y
  *@param turno Turno que esta presente en el juego
  *@return boolean Te dice si es un movimiento valido
  */
  public boolean movimientoValido(Tablero t, int xi, int yi, int xf, int yf, boolean turno){
    return false;
  }
}
