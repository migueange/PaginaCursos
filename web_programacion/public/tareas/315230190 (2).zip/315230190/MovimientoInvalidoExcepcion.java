/**
*@author Miguel Torres Eric Giovanni
*@version 1.0
*/
public class MovimientoInvalidoExcepcion extends Exception{
  /**
  *Constructor por omision que manda el mensaje movimiento invalido
  */
  public MovimientoInvalidoExcepcion(){
    super("MOVIMIENTO INVALIDO");
  }
  /**
  *Constructor con parametros
  *@param msg Es el mensaje que enviara al usuario
  */
  public MovimientoInvalidoExcepcion(String msg){
    super(msg);
  }
}
