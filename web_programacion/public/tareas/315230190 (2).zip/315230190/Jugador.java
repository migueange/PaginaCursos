/**
*@author Miguel Torres Eric Giovanni
*@version 1.0
*/
public class Jugador{
  private String nombre;
  private boolean turno;
  /**
  *Constructor con parametros que recibe el nombre del jugador y el color que moverá
  *@param nom Es el nombre del jugador
  *@param turn Es el turno, true es blanco y false es negro
  */
  public Jugador(String nom, boolean turn){
    nombre = nom;
    turno = turn;
  }
  /**
  *Metodo que te devuelve el nombre
  *@return String Es el nombre del jugador
  */
  public String obtenerNombre(){
    return nombre;
  }
  /**
  *Metodo que te devuelve el turno
  *@return boolean Es el color que te devuelve
  */
  public boolean obtenerTurno(){
    return turno;
  }
  /**
  *Metodo que te permite asignar nombre
  *@param nom Es el nombre que asignaras
  */
  public void asignaNombre(String nom){
    nombre = nom;
  }
  /**
  *Metodo que te permite asignar el turno
  *@param turn Es el turno que asignaras
  */
  public void asignaTurno(boolean turn){
    turno = turn;
  }
  /**
  *Metodo toString de la clase Jugador
  *@return String Es el texto que te devolvera al aplicar este metodo
  */
  public String toString(){
    if(turno == true){
      return "Jugador: " + nombre + ", con color blancas";
    }else
      return "Jugador: " + nombre + ", con color negras";
  }
}
