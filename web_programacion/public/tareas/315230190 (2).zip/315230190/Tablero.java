
/**
*@author Miguel Torres Eric Giovanni
*@version 1.0
*/
public class Tablero{
  private Piezas tablero[][];
  /**
  *Constructor por omision que crea un tablero de 6*6 con las piezas colocadas
  */
  public Tablero(){
    tablero = new Piezas[6][6];
    for(int i = 0; i < tablero.length; i++){
      for(int j = 0; j < tablero[i].length; j++){
        if(i == 1){
          tablero[i][j] = new Peon(true,i,j);
        }else if(i == 4){
          tablero[i][j] = new Peon(false,i,j);
        }else if(i == 0){
          if(j == 0 || j == 5){
            tablero[i][j] = new Torre(true,i,j);
          }else if(j == 1 || j == 4){
            tablero[i][j] = new Caballo(true,i,j);
          }else if(j == 2){
            tablero[i][j] = new Rey(true,i,j);
          }else if(j == 3){
            tablero[i][j] = new Dama(true,i,j);
          }
        }else if(i == 5){
          if(j == 0 || j == 5){
            tablero[i][j] = new Torre(false,i,j);
          }else if(j == 1 || j == 4){
            tablero[i][j] = new Caballo(false,i,j);
          }else if(j == 3){
            tablero[i][j] = new Rey(false,i,j);
          }else if(j == 2){
            tablero[i][j] = new Dama(false,i,j);
          }
        }else{
          tablero[i][j] = new Vacia(true,i,j);
        }
      }
    }
  }
  public void asignarPieza(Piezas p, int x, int y){
    tablero[y][x] = p;
  }
  public Piezas obtenerPieza(int x, int y){
    return tablero[y][x];
  }
  /**
  *Metodo que pasa a string el tablero
  *@return String Es el tablero en cadena de texto
  */
  public String toString(){
    String t = "";
    for(int i = 0; i < tablero.length; i++){
      for(int j = 0; j < tablero[i].length; j++){
        t += " ";
        if((j % 6) == 0)
          t+="\n";
        t += tablero[i][j].toString();
        if(j == 5){
          t += " " + i + " ";
        }
      }
    }
    t += "\n";
    for(int i = 0; i < tablero.length; i++){
      for(int j = 0; j < tablero.length; j++){
        if(i == 0){
          t += j;
        }
        t += " ";
      }
    }
    return t;
  }
}
