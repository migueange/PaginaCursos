
import java.time.LocalDate;
/**
* Clase que sirve para tener todos los datos de eventos.
* @author Edgar Quiroz
* @version 1.0
*/
public class Evento{
  String nombre;
  double precio;
  LocalDate fecha;
  int boletos;

  /**
  * Constructor con parámetros
  * @param n Cadena con el nombre del evento
  * @param p Double con el precio del evento
  * @param f LocalDate con la fecha del evento
  * @param b Entero con la cantidad de boletos inicialmente disponibles
  */
  public Evento(String n, double p, LocalDate f, int b){
    nombre = n;
    fecha = f;
    precio  = (p >= 0) ? p : 0;
    boletos = (b >= 0) ? b : 0;
  }
}
