import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
/**
* Clase de boleto de prepago
* @author Edgar Quiroz
* @version 1.0
*/
public class BoletoPre extends Boleto{
  private LocalDate hoy;

  /**
  * Constructor con parámetros. Dependiendo de la anticipación con la que se compren cambia el precio.
  * @param e Es el evento del que se quiere adquirir un boleto
  * @param h Es la fecha del día de hoy
  */
  public BoletoPre(Evento e, LocalDate h){
    super(e);
    hoy = h;

    if(hoy.until(fecha, ChronoUnit.DAYS) >= 3){
      modTipoBoleto('P');
      if(hoy.until(fecha, ChronoUnit.DAYS) >= 20){
        asignarPrecio(precio * 0.8);
      }else {
        if(hoy.until(fecha, ChronoUnit.DAYS) >= 10){
          asignarPrecio(precio * 0.9);
        }
      }
    } else {
      System.out.println("Evento demasiado cercano. Se procesará como boleto normal.");
    }

  }
}
