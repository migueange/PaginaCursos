import java.time.LocalDate;
/**
* Clase de boletos de estudiantes.
* @author Edgar Quiroz
* @version 1.0
*/
public class BoletoE extends Boleto {
  /**
  * Constructor con parámetros. De tener credencial válida recibe 50% de descuento.
  * @param e Es el evento del que se quiere adquirir un boleto
  * @param id Es una cadena que representa a la credencial
  */
  public BoletoE(Evento e, String id){
    super(e);
    if(id.equals("UNAM") || id.equals("IPN") || id.equals("UAM")){
      asignarPrecio(precio * 0.5);
      modTipoBoleto('E');
    } else {
      System.out.println("Credencial inválida. Se procesara como boleto normal.");
    }
  }
}
