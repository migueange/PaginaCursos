import java.time.LocalDate;
/**
* Clase de boletos
* @author Edgar Quiroz
* @version 1.0
*/
public class Boleto{
  protected static int folio = 100;
  protected String clave;
  protected String evento;
  protected double precio;
  protected LocalDate fecha;

  /**
  * Constructor con parámetros
  * @param e Es el evento del que se quiere adquirir un boleto
  */
  public Boleto(Evento e){
    evento = e.nombre;
    fecha = e.fecha;
    precio = e.precio;
    clave = "BN-" + folio;
    folio ++;
  }

  /**
  * Método para cambiar el precio del boleto
  * @param p Es el nuevo precio del boleto
  */
  public void asignarPrecio(double p){
    precio = p;
  }

  /**
  * Método para cambiar el tipo de boleto
  * @param c Es un caracter que modificará el tipo de boleto
  */
  public void modTipoBoleto(char c){
    char[] claveChar = clave.toCharArray();
    claveChar[1] = c;
    clave = String.valueOf(claveChar);
  }

  /**
  * Método para obtener los datos del boleto en una cadena
  * @return Cadena que contiene los atributos del boleto
  */
  public String toString(){
    return "Evento: " + evento + "\n" +
           "Clave: " + clave + "\n" +
           "Precio: $" + precio + "\n" +
           "Fecha: " + fecha;
  }
}
