import java.util.Scanner;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.ChronoUnit;

public class PruebaBoletos{
  public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    int s, t, nB;
    Evento e;
    String id;
    Boleto b = null;
    Evento [] eventos = {new Evento("Metallica", 700, LocalDate.of(2017, Month.NOVEMBER, 20), 1), new Evento("Filarmonica", 500, LocalDate.of(2017, Month.DECEMBER, 10), 500), new Evento("Justice League", 100, LocalDate.of(2017, Month.DECEMBER, 17), 100)};

    System.out.println("Bienvenido");
    do{
      System.out.println("Eliga el evento");
      System.out.println("1 Concierto de metallica\n2 Concierto de la filarmonica de Berlin\n3 Proyección de la película 'Justice League' \n4 Salir");
      s = in.nextInt();
      if(s < 4 && s > 0){
        e = eventos[s-1];
        System.out.println("¿Cuántos boletos deseas comprar?");
        nB = in.nextInt();

        if(nB > 0 && nB <= e.boletos){
          for (int i = 0; i < nB; i ++){
            System.out.println("Eliga el tipo del boleto " + (i+1));
            System.out.println("1 Normal\n2 De prepago\n3 De estudiante\n4 Tercera edad");
            t = in.nextInt();
            e.boletos --;
            switch (t) {
              case 1: b =  new Boleto(e);
              break;
              case 2: b =  new BoletoPre(e, LocalDate.now());
              break;
              case 3: System.out.println("Introduzca su credencial");
                      id = in.next();
                      b =  new BoletoE(e, id);
              break;
              case 4: System.out.println("Introduzca su credencial");
                      id = in.next();
                      b =  new BoletoE(e, id);
              break;
              default: System.out.println("Tipo no válido\n");
              break;
            }
            if(b != null){
              System.out.println("Su compra del fue \n" + b.toString() + "\n");
            }
          }
        } else {
          System.out.println("Cantidad no válida de boletos");
        }
      } else {
        if(s != 4){
          System.out.println("Elija algo válido");
        }
      }
    } while(s != 4);
    System.out.println("Gracias por su preferencia, vuelva pronto");
  }
}
