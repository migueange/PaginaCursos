import java.time.LocalDate;
/**
* Clase de boletos de personas de la tercera edad.
* @author Edgar Quiroz
* @version 1.0
*/
public class Boleto3 extends Boleto{
  /**
  * Constructor con parámetros. De tener credencial válida todos los boletos costarán $10.
  * @param e Es el evento del que se quiere adquirir un boleto
  * @param id Es una cadena que representa a la credencial
  */
  public Boleto3(Evento e, String id){
    super(e);
    if (id.equals("INSEN")){
      asignarPrecio(10);
      modTipoBoleto('3');
    } else {
        System.out.println("Credencial inválida. Se procesara como boleto normal.");
    }
  }
}
