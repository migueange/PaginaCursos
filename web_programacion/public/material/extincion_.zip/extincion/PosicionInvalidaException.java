/**
 * Calse para manejar errore en matrices
 * @author Ramses Lopez Soto
 * @version diciembre 2017
 */
 public class PosicionInvalidaException extends Exception{

   /**
    * Constructor por omision
    */
    public PosicionInvalidaException(){
      super();
    }

    /**
     * Constructor para enviar un mensaje de error
     * @param msj mensaje de error
     */
     public PosicionInvalidaException(String msj){
       super(msj);
     }

 }
