/**
 * Clase para simular las piezas del juego de extincion
 * @author Ramses Lopez Soto
 * @version diciembre 2017
 */
 public abstract class Pieza{

   /*nombre de la pieza*/
   protected String nombre;
   /*color de la pieza*/
   protected String color;
   /*fila del tablero*/
   protected int fila;
   /*columna de la fila*/
   protected int columna;

   /**
    * Constructor por omision
    */
    public Pieza(){
      nombre = " ";
      color = " ";
      fila = 0;
      columna = 0;
    }

    public Pieza(String nombre, String color){
      this.nombre = nombre;
      this.color = color;
    }

    /**
     * Metodo para conocer el nombre de la pieza
     * @return String - nombre de la pieza
     */
     public String obtenerNombre(){
       return nombre;
     }

     /**
      * Metodo para asignar un nombre a la pieza
      * @param n nombre de la pieza
      */
      public void asignarNombre(String n){
        nombre = n;
      }

   /**
    * Metodo para conocer el color de la pieza
    * @return String - color de la pieza
    */
    public String obtenerColor(){
      return color;
    }

    /**
     * Metodo para asignar un nuevo color a la pieza
     * @param c nuevo color a asignar
     */
     public void asignarColor(String c){
       color = c;
     }

     /**
      * Metodo para conocer la fila
      * @return int - fila donde se encuentra la pieza
      */
      public int obtenerFila(){
        return fila;
      }

      /**
       * Metodo ṕara asignar una fila
       * @param f fila a asignar
       */
       public void asignarFila(int f){
         fila = f;
       }

       /**
        * Metodo para conocer la columna
        * @return int - columna donde se encuentra la pieza
        */
        public int obtenerColumna(){
          return columna;
        }

        /**
         * Metodo ṕara asignar una columna
         * @param col columna a asignar
         */
         public void asignarColumna(int col){
           columna = col;
         }

     /**
      * Metodo para mover la pieza sobre el tablero
      * @param fila fila de la pieza
      * @param columna columna de la pieza
      * @throws PosicionInvalidaException - manda un mensaje de error si no puede realizar el movimiento
      */
      public abstract void moverPieza(int fila, int columna) throws PosicionInvalidaException;
 }
