/**
 * Clase que simula el tablero de un juego de extincion
 * @author Ramses Lopez Soto
 * @version diciembre 2017
 */
 public class Tablero {

   /*tablero*/
   private Casilla [][] tablero;
   /*renglones del tablero*/
   private final int filas = 6;
   /*columnas*/
   private final int columnas = 6;

   /**
   * Constructor para crear el tablero 6x6
   */
   public Tablero() {
     tablero = new Casilla [filas][columnas];
     for (int i = 0; i < filas; i++) {
       for (int j = 0; j < columnas; j++) {
         tablero[i][j] = null;
       }
     }
   }

   /**
    * Constructor de copia
    * @param m matriz que se copiara
    */
    public Tablero(Tablero m){
      tablero = m.obtenerTablero();
    }

    /**
     * Metodo para conocer el numero de renglones
     * @return int - numero de renglones del tablero
     */
     public int obtenerFilas() {
       return tablero.length;
     }

     /**
      * Metodo para conocer el numero de columnas del tablero
      * @return int - numero de columnas del tablero
      */
      public int obtenerColumnas() {
        return tablero[0].length;
      }

      /**
       * Metodo para obtener el tablero
       * @return Matriz - tablero del juego
       */
       public Casilla[][] obtenerTablero(){
         return tablero;
       }

       public void imprimeTablero(){
           for(int i=0; i < filas; i++){
               for(int j=0; j < columnas; j++){
                   System.out.print(tablero[i][j] + "\t");
                  }
               System.out.println("\n");
             }
       }

 }
