/**
 * Clase que simula la pieza peon
 * @see Pieza
 * @author Ramses Lopez Soto
 * @version diciembre 2017
 */
 public class Peon extends Pieza{

   /**
    * Construye la pieza del peon
    * @param color color de la pieza
    */
    public Peon(String color){
      super("Peon", color);
    }

   /**
    * Metodo para mover la pieza sobre el tablero
    * @param fila fila de la pieza
    * @param columna columna de la pieza
    * @throws PosicionInvalidaException - manda un mensaje de error si no puede realizar el movimiento
    */
    public void moverPieza(int fila, int columna) throws PosicionInvalidaException{
      if ((fila++ == obtenerFila()) && (columna == obtenerColumna())) {
        System.out.println("Has movido al peon");
      } else {
        throw new PosicionInvalidaException("No puedes mover la pieza a ese sitio");
      }
    }

    public String toString(){
      return "Peon";
    }
 }
