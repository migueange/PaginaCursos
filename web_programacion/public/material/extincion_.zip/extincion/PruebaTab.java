
public class PruebaTab{

  public static void imprimeTablero(Pieza [][] tablero, int filas, int columnas){
      for(int i=0; i < filas; i++){
          for(int j=0; j < columnas; j++){
              System.out.print(tablero[i][j] + "\t");
             }
          System.out.println("\n");
        }
  }
  public static void main(String[] args) {
    Pieza p = new Peon("Balnca");
    Pieza p2 = new Peon("Balnca");
    Pieza p3 = new Peon("Balnca");
    Pieza p4 = new Peon("Balnca");
    Pieza p5 = new Peon("Balnca");
    Pieza p6 = new Peon("Balnca");
    Pieza c = new Caballo("Balnca");
    Pieza c2 = new Caballo("Balnca");
    Pieza t1 = new Torre("Balnca");
    Pieza t2 = new Torre("Balnca");
    Pieza r = new Rey("Balnca");
    Pieza rt = new Reina("Balnca");
    Pieza [][] t = {
      {t1, c,r,rt,c2,t2},
      {p, p2,p3,p4,p5,p6},
      {null, null,null,null,null,null},
      {null, null,null,null,null,null},
      {null, null,null,null,null,null},
      {null, null,null,null,null,null}
    };
    imprimeTablero(t,6,6);
    try{
    c.moverPieza(1,2);
    imprimeTablero(t,6,6);
  }catch(PosicionInvalidaException e){
    System.out.println(e);
  }
  }
}
