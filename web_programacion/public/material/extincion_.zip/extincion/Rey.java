/**
 * Clase que simula la pieza rey
 * @see Pieza
 * @author Ramses Lopez Soto
 * @version diciembre 2017
 */
 public class Rey extends Pieza{

   /**
    * Construye la pieza del rey
    * @param color color de la pieza
    */
    public Rey(String color){
      super("Rey", color);
    }

   /**
    * Metodo para mover la pieza sobre el tablero
    * @param fila fila de la pieza
    * @param columna columna de la pieza
    * @throws PosicionInvalidaException - manda un mensaje de error si no puede realizar el movimiento
    */
    public void moverPieza(int fila, int columna) throws PosicionInvalidaException{
      if ((Math.abs(fila - obtenerFila()) <= 1) && (Math.abs(columna - obtenerColumna()) <= 1)) {
        System.out.println("Has movido al rey");
      } else {
        throw new PosicionInvalidaException("No puedes mover la pieza a ese sitio");
      }
    }

    public String toString(){
      return "Rey";
    }
 }
