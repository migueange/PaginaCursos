/**
 * Clase que simula la pieza caballo
 * @see Pieza
 * @author Ramses Lopez Soto
 * @version diciembre 2017
 */
 public class Caballo extends Pieza{

   /**
    * Constrye la pieza del caballo
    * @param color color de la pieza
    */
    public Caballo(String color){
      super("Caballo", color);
    }

   /**
    * Metodo para mover la pieza sobre el tablero
    * @param fila fila de la pieza
    * @param columna columna de la pieza
    * @throws PosicionInvalidaException - manda un mensaje de error si no puede realizar el movimiento
    */
    public void moverPieza(int fila, int columna) throws PosicionInvalidaException{
      if ((((fila - obtenerFila()) * (fila - obtenerFila())) + ((columna - obtenerColumna()) * (columna - obtenerColumna()))) == 5) {
        System.out.println("Has movido al caballo");
      } else {
        throw new PosicionInvalidaException("No puedes mover la pieza a ese sitio");
      }
    }

    public String toString(){
      return "Caballo";
    }
 }
